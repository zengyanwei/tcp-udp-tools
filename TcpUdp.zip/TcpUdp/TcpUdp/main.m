//
//  main.m
//  TcpUdp
//
//  Created by 曾 言伟 on 15/9/23.
//  Copyright © 2015年 曾 言伟. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

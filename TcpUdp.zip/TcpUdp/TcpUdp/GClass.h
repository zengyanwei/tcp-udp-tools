//
//  GClass.h
//  aaarrrccc
//
//  Created by vidonn on 15/9/24.
//  Copyright © 2015年 vidonn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GClass : NSObject

+ (NSString *)deviceIPAdress;
+ (void)myAlertView:(NSString*)str delegate:(id)delegate type:(int)t;
@end

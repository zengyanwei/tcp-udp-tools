//
//  ViewController.h
//  TcpUdp
//
//  Created by 曾 言伟 on 15/9/23.
//  Copyright © 2015年 曾 言伟. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncSocket.h"
#import "AsyncUdpSocket.h"

@interface ViewController : UIViewController<UITextViewDelegate,AsyncSocketDelegate>
{
    AsyncSocket *clientSocket;
    AsyncSocket *acceptSocket;
    AsyncSocket *listenSocket;
    AsyncUdpSocket *udpSocket;
}

@end


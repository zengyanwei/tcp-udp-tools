//
//  AppDelegate.h
//  TcpUdp
//
//  Created by 曾 言伟 on 15/9/23.
//  Copyright © 2015年 曾 言伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


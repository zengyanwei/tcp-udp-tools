//
//  ViewController.m
//  TcpUdp
//
//  Created by 曾 言伟 on 15/9/23.
//  Copyright © 2015年 曾 言伟. All rights reserved.
//

#import "ViewController.h"
#import "GClass.h"

@interface ViewController ()
{
    UILabel* showtxt;
    BOOL isRunning;
    int oldSelindex;
    long revnum;
    long sendnum;
    NSTimer *contentTimer;
}
@property (weak, nonatomic) IBOutlet UIView *revText;
@property (weak, nonatomic) IBOutlet UIView *sendText;
@property (weak, nonatomic) IBOutlet UIView *leftview;
@property (weak, nonatomic) IBOutlet UIView *leftbtview;
@property (weak, nonatomic) IBOutlet UITextField *bjport;
@property (weak, nonatomic) IBOutlet UITextField *ycport;
@property (weak, nonatomic) IBOutlet UITextField *ycip;
@property (weak, nonatomic) IBOutlet UITextField *fstime;
@property (weak, nonatomic) IBOutlet UIButton *conBtn;
@property (weak, nonatomic) IBOutlet UIButton *sendBtn;
@property (weak, nonatomic) IBOutlet UITextView *revValue;
@property (weak, nonatomic) IBOutlet UITextView *sendValue;
@property (weak, nonatomic) IBOutlet UILabel *revNum;
@property (weak, nonatomic) IBOutlet UILabel *sendNum;
@property (weak, nonatomic) IBOutlet UILabel *ip;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    oldSelindex = 0;
    self.ip.text = [NSString stringWithFormat:@"Local WIFI IP: %@",[GClass deviceIPAdress]];;
    [self.revText.layer setMasksToBounds:YES];
    [self.revText.layer setCornerRadius:1.0];
    self.revText.layer.borderColor = [UIColor colorWithRed:79.0/255.0 green:173.0/255.0 blue:233.0/255.0 alpha:1.0].CGColor;
    self.revText.layer.borderWidth = 1.0;
    
    [self.sendText.layer setMasksToBounds:YES];
    [self.sendText.layer setCornerRadius:1.0];
    self.sendText.layer.borderColor = [UIColor colorWithRed:79.0/255.0 green:173.0/255.0 blue:233.0/255.0 alpha:1.0].CGColor;
    self.sendText.layer.borderWidth = 1.0;
    
    [self.leftview.layer setMasksToBounds:YES];
    [self.leftview.layer setCornerRadius:1.0];
    self.leftview.layer.borderColor = [UIColor colorWithRed:79.0/255.0 green:173.0/255.0 blue:233.0/255.0 alpha:1.0].CGColor;
    self.leftview.layer.borderWidth = 1.0;
    
    [self.leftbtview.layer setMasksToBounds:YES];
    [self.leftbtview.layer setCornerRadius:1.0];
    self.leftbtview.layer.borderColor = [UIColor colorWithRed:79.0/255.0 green:173.0/255.0 blue:233.0/255.0 alpha:1.0].CGColor;
    self.leftbtview.layer.borderWidth = 1.0;
    [self initNet];
}

-(void) initNet
{
    listenSocket = [[AsyncSocket alloc] initWithDelegate:self];
    [listenSocket setRunLoopModes:[NSArray arrayWithObject:NSRunLoopCommonModes]];
    clientSocket = [[AsyncSocket alloc] initWithDelegate:self];
    [clientSocket setRunLoopModes:[NSArray arrayWithObject:NSRunLoopCommonModes]];
    
}

- (BOOL) startListen:(UInt16) port
{
    if(port == 0)
    {
        [GClass myAlertView:NSLocalizedString(@"qbdk", nil) delegate:self type:0];
        return NO;
    }
    if (!isRunning)
    {
        NSError *error = nil;
        [listenSocket acceptOnPort:port error:&error];
        NSLog(@"acceptOnPort error = %@",error);
        isRunning = YES;
        return YES;
    }
    return NO;
}

- (void)stopListen
{
    if (isRunning)
    {
        [listenSocket disconnect];
        isRunning = NO;
    }
}

- (BOOL) connectHost
{
    if(self.ycport.text.length == 0 || self.ycip.text.length == 0)
    {
        [GClass myAlertView:NSLocalizedString(@"qydk", nil) delegate:self type:0];
        return NO;
    }
    if (![clientSocket isConnected])
    {
        NSError *error = nil;
        [clientSocket connectToHost:self.ycip.text onPort:[self.ycport.text intValue] withTimeout:-1 error:&error];
        if (error)
        {
            NSLog(@"connectToHost error %@",error);
            [clientSocket disconnect];
            return NO;
        }
        return YES;
    }
    return NO;
}

- (void) disconnectHost
{
    [clientSocket disconnect];
}

-(BOOL) startUdp
{
    if(self.bjport.text.length == 0 || self.ycport.text.length == 0 || self.ycip.text.length == 0)
    {
        [GClass myAlertView:NSLocalizedString(@"qydkip", nil) delegate:self type:0];
        return NO;
    }
    NSError *error = nil;
    udpSocket = [[AsyncUdpSocket alloc] initWithDelegate:self];
    [udpSocket setRunLoopModes:[NSArray arrayWithObject:NSRunLoopCommonModes]];
    if([udpSocket localPort] == 0)
    {
        [udpSocket bindToPort:[self.bjport.text intValue] error:&error];
        if(error)
        {
            return NO;
        }
        [udpSocket receiveWithTimeout:-1 tag:0];
        return YES;
    }
    return NO;
}

-(void) closeUdp
{
    [udpSocket close];
}

-(void) showDara:(NSString*) value
{
    revnum += [value length];
    NSString* oldvalue = self.revValue.text;
    self.revValue.text = [oldvalue stringByAppendingString:value];
    self.revNum.text = [NSString stringWithFormat:@"%lu 字节",revnum];
    self.revValue.text = [self.revValue.text stringByAppendingString:@"\n"];
}

-(void) conerror
{
    if(oldSelindex == 0)
    {
        [self stopListen];
        [self.conBtn setTitle:NSLocalizedString(@"ksjt", nil) forState:UIControlStateNormal];
    }
    else if(oldSelindex == 1)
    {
        [self disconnectHost];
        [self.conBtn setTitle:NSLocalizedString(@"linj", nil) forState:UIControlStateNormal];
    }
    else if(oldSelindex == 2)
    {
        [self closeUdp];
        [self.conBtn setTitle:NSLocalizedString(@"cjudp", nil) forState:UIControlStateNormal];
    }
    [GClass myAlertView:NSLocalizedString(@"ljdk", nil) delegate:self type:0];
}

-(void) TcpSend:(NSString*) value
{
    if([value length] == 0)
        return;
    sendnum += [value length];
    if(oldSelindex == 0)
        [acceptSocket writeData:[value dataUsingEncoding: NSUTF8StringEncoding] withTimeout:-1 tag:0];
    else if(oldSelindex == 1)
        [clientSocket writeData:[value dataUsingEncoding: NSUTF8StringEncoding] withTimeout:-1 tag:0];
    else if(oldSelindex == 2)
        [udpSocket sendData:[value dataUsingEncoding: NSUTF8StringEncoding] toHost:self.ycip.text port:[self.ycport.text intValue] withTimeout:-1 tag:0];
    self.sendNum.text = [NSString stringWithFormat:@"%lu 字节",sendnum];
}

- (IBAction)ConnectAct:(UISegmentedControl *)sender {
    switch (sender.selectedSegmentIndex) {
        case 0:
            if(oldSelindex == 1)
               [self disconnectHost];
            else if(oldSelindex == 2)
               [self closeUdp];
            [self.ycport setEnabled:NO];
            [self.ycip setEnabled:NO];
            [self.bjport setEnabled:YES];
            [self.conBtn setTitle:NSLocalizedString(@"ksjt", nil) forState:UIControlStateNormal];
            break;
        case 1:
            if(oldSelindex == 0)
                [self stopListen];
            else if(oldSelindex == 2)
                [self closeUdp];
            [self.ycport setEnabled:YES];
            [self.ycip setEnabled:YES];
            [self.bjport setEnabled:NO];
            [self.conBtn setTitle:NSLocalizedString(@"linj", nil) forState:UIControlStateNormal];
            break;
        case 2:
            if(oldSelindex == 0)
                [self stopListen];
            else if(oldSelindex == 1)
                [self disconnectHost];
            [self.ycport setEnabled:YES];
            [self.ycip setEnabled:YES];
            [self.bjport setEnabled:YES];
            [self.conBtn setTitle:NSLocalizedString(@"cjudp", nil) forState:UIControlStateNormal];
            break;
        default:
            break;
    }
    oldSelindex = (int)sender.selectedSegmentIndex;
}
- (IBAction)SendAct:(UISegmentedControl *)sender {
    switch (sender.selectedSegmentIndex) {
        case 0:
            [self.fstime setEnabled:NO];
            [self.sendBtn setEnabled:YES];
            [contentTimer invalidate];
            contentTimer = nil;
            break;
        case 1:
            [self.fstime setEnabled:YES];
            [self.sendBtn setEnabled:NO];
            [self initTimer:[self.fstime.text length] == 0 ? 1.0 : [self.fstime.text floatValue] / 1000.0];
            break;
        default:
            break;
    }
}

- (void)initTimer:(float)time {
    contentTimer = [NSTimer timerWithTimeInterval:time
                                                    target:self
                                                  selector:@selector(cycleConnec:)
                                                  userInfo:nil
                                                   repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:contentTimer
                                 forMode:NSDefaultRunLoopMode];
}

- (void)cycleConnec:(NSTimer *)timer
{
    [self TcpSend:self.sendValue.text];
}

- (IBAction)conBtn:(UIButton *)sender {
    if([sender.titleLabel.text isEqualToString:NSLocalizedString(@"ksjt", nil)] ){
        if([self startListen:[self.bjport.text intValue]])
           [self.conBtn setTitle:NSLocalizedString(@"tizjt", nil) forState:UIControlStateNormal];
    }
    else if([sender.titleLabel.text isEqualToString:NSLocalizedString(@"tizjt", nil)]){
        [self stopListen];
        [self.conBtn setTitle:NSLocalizedString(@"ksjt", nil) forState:UIControlStateNormal];
    }
    else if([sender.titleLabel.text isEqualToString:NSLocalizedString(@"linj", nil)]){
        if([self connectHost])
           [self.conBtn setTitle:NSLocalizedString(@"dlinj", nil) forState:UIControlStateNormal];
    }
    else if([sender.titleLabel.text isEqualToString:NSLocalizedString(@"dlinj", nil)]){
        [self disconnectHost];
        [self.conBtn setTitle:NSLocalizedString(@"linj", nil) forState:UIControlStateNormal];
    }
    else if([sender.titleLabel.text isEqualToString:NSLocalizedString(@"cjudp", nil)]){
        if([self startUdp])
           [self.conBtn setTitle:NSLocalizedString(@"tizudp", nil) forState:UIControlStateNormal];
    }
    else if([sender.titleLabel.text isEqualToString:NSLocalizedString(@"tizudp", nil)]){
        [self closeUdp];
        [self.conBtn setTitle:NSLocalizedString(@"cjudp", nil) forState:UIControlStateNormal];
    }
}
- (IBAction)SendBtn:(UIButton *)sender {
    [self TcpSend:self.sendValue.text];
}
- (IBAction)ClearRevBtn:(UIButton *)sender {
    self.revValue.text = @"";
    revnum = 0;
    self.revNum.text = [NSString stringWithFormat:@"0 %@",NSLocalizedString(@"ziji", nil)];
}
- (IBAction)ClearSendBtn:(UIButton *)sender {
    self.sendValue.text = @"";
    sendnum = 0;
    self.sendNum.text = [NSString stringWithFormat:@"0 %@",NSLocalizedString(@"ziji", nil)];
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    CGFloat  offset = self.view.frame.size.width - (textView.frame.origin.y + textView.frame.size.height + 352 - 20);
   // if(offset <= 0)
    {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = self.view.frame;
            frame.origin.y = - offset;
            self.view.frame = frame;
        }];
    }
    return YES;
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView {
    [UIView animateWithDuration:0.3 animations:^{
        CGRect frame = self.view.frame;
        frame.origin.y = 0.0;
        self.view.frame = frame;
    }];
     return YES;
}

- (IBAction)BeginEditTime:(UITextField *)sender {
    CGFloat  offset = self.view.frame.size.width - (self.sendValue.frame.origin.y + self.sendValue.frame.size.height + 352 - 20);
    // if(offset <= 0)
    {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = self.view.frame;
            frame.origin.y = - offset;
            self.view.frame = frame;
        }];
    }
}

- (IBAction)EndEditTime:(UITextField *)sender {
    [UIView animateWithDuration:0.3 animations:^{
        CGRect frame = self.view.frame;
        frame.origin.y = 0.0;
        self.view.frame = frame;
    }];
    [contentTimer invalidate];
    contentTimer = nil;
    [self initTimer:[self.fstime.text length] == 0 ? 1.0 : [self.fstime.text floatValue] / 1000.0];
}



#pragma mark - AsyncSocketDelegate
/**
 *  socket发生错误时,socket关闭；连接时可能被调用，主要用于socket连接错误时读取错误发生前的数据
 *
 *  @param sock <#sock description#>
 *  @param err  <#err description#>
 */
- (void)onSocket:(AsyncSocket *)sock willDisconnectWithError:(NSError *)err
{
    NSLog(@"Server willDisconnectWithError");
    [self performSelectorOnMainThread:@selector(conerror) withObject:nil waitUntilDone:NO];
}

/**
 *  socket断开连接后被调用，你调用disconnect方法，还没有断开连接，只有调用这个方法时，才断开连接
 *
 *  @param sock <#sock description#>
 */
- (void)onSocketDidDisconnect:(AsyncSocket *)sock
{
    NSLog(@"Server onSocketDidDisconnect");
    acceptSocket = nil;
}

/**
 *  监听到新连接时被调用，这个新socket的代理和listen socket相同
 *
 *  @param sock      <#sock description#>
 *  @param newSocket <#newSocket description#>
 */
- (void)onSocket:(AsyncSocket *)sock didAcceptNewSocket:(AsyncSocket *)newSocket
{
    NSLog(@"Server didAcceptNewSocket");
    if (!acceptSocket) {
        acceptSocket = newSocket;
        NSLog(@"did accept new socket");
    }
}

/**
 *  连接服务器成功
 *
 *  @param sock <#sock description#>
 *  @param host <#host description#>
 *  @param port <#port description#>
 */
- (void)onSocket:(AsyncSocket *)sock didConnectToHost:(NSString *)host port:(UInt16)port
{
    NSLog(@"client didConnectToHost");
    //这是异步返回的连接成功，
    if(oldSelindex == 0)
        [acceptSocket readDataWithTimeout:-1 tag:0];
    else if(oldSelindex == 1)
        [clientSocket readDataWithTimeout:-1 tag:0];
}

/**
 *  Called when a new socket is spawned to handle a connection.  This method should return the run-loop of the
 *
 *  @param sock      <#sock description#>
 *  @param newSocket <#newSocket description#>
 *
 *  @return <#return value description#>
 */
- (NSRunLoop *)onSocket:(AsyncSocket *)sock wantsRunLoopForNewSocket:(AsyncSocket *)newSocket
{
    NSLog(@"Server wantsRunLoopForNewSocket");
    return [NSRunLoop currentRunLoop];
}

/**
 *  Called when a socket is about to connect. This method should return YES to continue, or NO to abort.If aborted, will result in AsyncSocketCanceledError.
 *
 *  @param sock <#sock description#>
 *
 *  @return <#return value description#>
 */
- (BOOL)onSocketWillConnect:(AsyncSocket *)sock
{
    NSLog(@"Server onSocketWillConnect");
    return YES;
}

/**
 *  <#Description#>
 *
 *  @param sock <#sock description#>
 *  @param data <#data description#>
 *  @param tag  <#tag description#>
 */
- (void)onSocket:(AsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
    [self performSelectorOnMainThread:@selector(showDara:) withObject:[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] waitUntilDone:YES];
    
    if(oldSelindex == 0)
        [acceptSocket readDataWithTimeout:-1 tag:0];
    else if(oldSelindex == 1)
        [clientSocket readDataWithTimeout:-1 tag:0];
}

/**
 *  Called when a socket has read in data, but has not yet completed the read.
 It may be used to for things such as updating progress bars.
 *
 *  @param sock          <#sock description#>
 *  @param partialLength <#partialLength description#>
 *  @param tag           <#tag description#>
 */
- (void)onSocket:(AsyncSocket *)sock didReadPartialDataOfLength:(NSUInteger)partialLength tag:(long)tag
{
    NSLog(@"Server didReadPartialDataOfLength = %d",partialLength);
}

/**
 *  Called when a socket has written some data, but has not yet completed the entire write.
 It may be used to for things such as updating progress bars.
 *
 *  @param sock          <#sock description#>
 *  @param partialLength <#partialLength description#>
 *  @param tag           <#tag description#>
 */
- (void)onSocket:(AsyncSocket *)sock didWritePartialDataOfLength:(NSUInteger)partialLength tag:(long)tag
{}

/**
 *  Called when a socket has completed writing the requested data. Not called if there is an error.
 *
 *  @param sock <#sock description#>
 *  @param tag  <#tag description#>
 */
- (void)onSocket:(AsyncSocket *)sock didWriteDataWithTag:(long)tag
{
     [acceptSocket readDataWithTimeout:-1 tag:0]; //如果是客户端调用
}

#pragma mark - AsyncUdpSocketDelegate

/**
 *  Called when the datagram with the given tag has been sent.
 *
 *  @param sock <#sock description#>
 *  @param tag  <#tag description#>
 */
- (void)onUdpSocket:(AsyncUdpSocket *)sock didSendDataWithTag:(long)tag
{
    
}

/**
 *  Called if an error occurs while trying to send a datagram.
 This could be due to a timeout, or something more serious such as the data being too large to fit in a sigle packet.
 *
 *  @param sock  <#sock description#>
 *  @param tag   <#tag description#>
 *  @param error <#error description#>
 */
- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotSendDataWithTag:(long)tag dueToError:(NSError *)error{
    
}

/**
 *  Called when the socket has received the requested datagram.
 *
 *  @param sock <#sock description#>
 *  @param data <#data description#>
 *  @param tag  <#tag description#>
 *  @param host <#host description#>
 *  @param port <#port description#>
 *
 *  @return <#return value description#>
 */
- (BOOL)onUdpSocket:(AsyncUdpSocket *)sock didReceiveData:(NSData *)data withTag:(long)tag fromHost:(NSString *)host port:(UInt16)port{
    [self performSelectorOnMainThread:@selector(showDara:) withObject:[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] waitUntilDone:YES];
    [udpSocket receiveWithTimeout:-1 tag:0];
    return YES;
}

/**
 *  Called if an error occurs while trying to receive a requested datagram.
 This is generally due to a timeout, but could potentially be something else if some kind of OS error occurred.
 *
 *  @param sock  <#sock description#>
 *  @param tag   <#tag description#>
 *  @param error <#error description#>
 */
- (void)onUdpSocket:(AsyncUdpSocket *)sock didNotReceiveDataWithTag:(long)tag dueToError:(NSError *)error{
    
}

/**
 *  Called when the socket is closed.
 A socket is only closed if you explicitly call one of the close methods.
 *
 *  @param sock <#sock description#>
 */
- (void)onUdpSocketDidClose:(AsyncUdpSocket *)sock{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
